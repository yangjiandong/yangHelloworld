This is the demo application that we're building to support the Lift Book.
http://www.github.com/tjweir/liftbook/


- Derek, Marius and Tyler
