/*
 * AllItems.scala
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.developerworks.snippet

import org.developerworks.model._
import net.liftweb.util.Full

class AllItems {
    def showAll = {
        val items = ItemMetaData.findAll
        println("Found #items=" + items.size)
        val s = items.map(_.tr).toSeq
        <table>
            <thead>
                <tr>
                    <td>name</td>
                    <td>bid</td>
                    <td>expiration</td>
                </tr>
            </thead>
            {s}
        </table>
    }
}
